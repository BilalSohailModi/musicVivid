<template>
  <div id="app">
     
         
<!-- <MusicPlayer v-if="$store.state.mp3.length>0" :key="$store.state.songid"></MusicPlayer> -->
<AudioPlayer v-if="$store.state.sound!==null" :key="$store.state.songid+Math.random()"></AudioPlayer>
         
        <router-view :key="$route.fullPath">
      
	
          </router-view>
   
  
  </div>
</template>
<script>
import {Howl, Howler} from 'howler';
import { ALL_PATH } from "@/Constants/Constants";
import MusicPlayer from "@/components/MusicPlayer.vue";
import AudioPlayer from "@/components/AudioPlayer.vue";
import { HELPER } from "@/Helper/Helper";
export default {
  name: 'AuthHeader',
  props: {
    msg: String
  },
  	components:{MusicPlayer,
    AudioPlayer},
	data () {
    return {
     
      user:"" ,
    profilemage:"",
    sound:null,
    audioList: [
        'http://txh-cdn.96qbhy.com/20180817175211dtC1vE3z.mp3',
        'http://txh-cdn.96qbhy.com/20181106105737sOcozMqw.mp3'
      ]
    
    }
	},
	
	methods:{

	},
  mounted(){
//     this.sound   = new Howl({
//        autoplay: true,
//   src: ['https://musicisvivid.s3.amazonaws.com/uploads/user_uploaded_musics/1550218666705R47pXDoGDf.mp3']
// });
window.onpopstate = event => {
 console.log(event)
    };
    
	},
	created(){




	},
  updated(){

	
	
	
	
	
  }
}
</script>
<style>

</style>
