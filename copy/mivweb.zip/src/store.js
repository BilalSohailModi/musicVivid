import Vue from 'vue'
import Vuex from 'vuex'
import router from './router'
import {Howl, Howler} from 'howler';
import {
  API
} from "@/api/api";

Vue.use(Vuex)
var container = null;



export default new Vuex.Store({
  state: {
      ispopup:false,
      isOtpPresent : false,
      isLeaderBoaedPayment : false,
    sound:null,
      registerdata:{
        username:"",
        fullName:"",
        dob:"",
        email:"",
        password:null,
        userType:null,
        gender:"",
        password_confirmation:null,
        error:false,
        errormessage:"",
        sucessMessage:"",
        data:null

      },
      registerstep2:false,
      otprecive:false,
      artistregisterstep1:true,
      artistregisterstep3:false,
      artistregisterstep4:false,
      registerdata2:{
        fullName:"",
        phoneNo:null,
        email:"",
        password:"",
        userType:'2',
        gender:null ,  ///1=Not mentioned, 2=Male, 3=Female
        signedType:null,
        prefferedChannel:null,
        channelName:"",
        address:"",
        latitude:null,
        longitude:null,
        baseGenreId:"",
        socialMediaFollowing:'1',
        answers: [] ,
        copyrightHolder:"",
        error:false,
        errormessage:"",
        sucessMessage:"",
      },
      songs:[],
      cal:null,
      mp3:[],
      songid:"",
      profilepicture:1,
      volume: 0.8,
      muted:false,
      isPlaying:false,
      isShow: true,
      startseek:false,
      startseekvol:false,
      muteshow:true
  },
  mutations: {
    playSongs:(state,payload)=>{
          console.log(payload);
      $("#cangespan").html('0:0') ;
      $('.progressive-length').css('width',   0 + '%');
      state.volume= 0.8;
      state.muted=false;
      state.isShow = true;
      state.mp3 = [] ;
      state.albumCoverImage = payload.albumCover;
      API.get(`song/${payload.songs[payload .index] .id}`, {
        headers: { "x-access-token": JSON.parse(localStorage.getItem("Token")) }
      })
      .then(response => {
       
      
          
          })
          .catch(error => {
           
          });
    
   
     if(state.sound != null){
      state.sound.pause();
     }
   
     state.sound = null;
    var src = payload.songs.map((e)=>{
      return e.src;
    });
    state.mp3 = payload;
      state.sound   = new Howl({
        autoplay: true,
        html5: true,
        volume: 0.5,
       src:  src[payload .index],
       onplay: function() {
        
       
          state.isPlaying = true;
         // step();
    
        // Display the duration.
        // duration.innerHTML = self.formatTime(Math.round(sound.duration()));

        // Start upating the progress of the track.
        // requestAnimationFrame(self.step.bind(self));

        // Start the wave animation if we have already loaded
        // wave.container.style.display = 'block';
        // bar.style.display = 'none';
        // pauseBtn.style.display = 'block';
      },
      onseek: function() {
    
    //  step();
      }
 });

 container =  state.sound 

 state.songid = payload .id;
 state.sound.play();
 
 function step(){
  
     var ctemp = state.sound;
     var seek = ctemp.seek() || 0;
     console.log("seek",seek);
  
    $("#cangespan").html(formatTime(Math.round(seek))) 
   //  progress.style.width = (((seek / sound.duration()) * 100) || 0) + '%';
   
     // If the sound is still playing, continue stepping.
     if (state.sound.playing()) {
      
     //  step();
     
     
     }
   }

   function  formatTime(secs){
    var minutes = Math.floor(secs / 60) || 0;
    var seconds = (secs - minutes * 60) || 0;
  
    return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
  }


    
      
     
      console.log( state.sound);
    },
  
    fanRgister:(state,payload) =>{
      console.log(payload.email);
      API.post("register",  {email:payload.email})
      .then(response => {
       
        if (response.data) {
         
             
        }
      })
      .catch(error => {
        let data = error.response.data.errors;
        console.log(data);
      
        console.log( state.registerdata);
          if(data.length ==1){
            state.registerdata. error= true;
            state.registerdata. errormessage = data[0].msg;
          }
       else{
        API.post("register",  payload)
        .then(response => {
         
          if (response.data) {
            console.log(response.data);
            localStorage.setItem("userEmail",response.data.users.email);
            API.post("send-otp-to-email",  {email:payload.email,  newUser: 1})
            .then(response => {
             
              if (response.data) {
                // var d = new Date();
                // var OtpExpTime = d.setMinutes(d.getMinutes() + 3);
                // localStorage.setItem("OtpExpTime", OtpExpTime);
               localStorage.setItem("Token",JSON.stringify(response.data.token));
                router.push({
                  name: "FanRegisterOtp"
                });
             //state.registerdata.registerstep2 = false; 
              }
            })
            .catch(error => {
             
            });
               
          }
        })
        .catch(error => {
          let data = error.response.data.errors;
          console.log(data);
          state.registerdata. error= true;
          state.registerdata. errormessage = data[0].msg;
          console.log( state.registerdata);
        });
       }
        
      });


     
    },

    artistRgister:(state,payload) =>{
      API.post("register",  payload)
      .then(response => {
       
        if (response.data) {
          console.log(response.data);
          state.registerdata2. error= false;
          state.registerdata2. errormessage = "";
          localStorage.setItem("User",JSON.stringify(response.data.users));
          router.push({
            name: "ArtistRegister4"
          });
       
             
        }
      })
      .catch(error => {
        let data = error.response.data.errors;
      console.log(data);
        state.registerdata2. error= true;
        state.registerdata2. errormessage = data[0].msg;
        console.log( state.registerdata);
      });
    },
    showmodal(){
      $('.modal-mask').removeClass('d-none').addClass('show');
    },
    hidemodal(){
      $('.modal-mask').removeClass('d-none').removeClass('show'); 
    },
    showmenu(){
      $('.header-right').addClass('active');
    },
	closemenu(){
      $('.header-right').removeClass('active');
    }
  },
  actions: {
      fanRgister:(context,payload) => {
       
      
       
      }
  }
})

