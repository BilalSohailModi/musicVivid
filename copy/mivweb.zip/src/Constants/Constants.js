export const ALL_PATH ={
    video_path:"https://musicisvivid.s3.amazonaws.com/uploads/user_uploaded_videos/",
    profile_image_path:"https://musicisvivid.s3.amazonaws.com/uploads/profile_pictures/",
    cover_pictures:"https://musicisvivid.s3.amazonaws.com/uploads/cover_pictures/",
    album_pictures:"https://musicisvivid.s3.amazonaws.com/uploads/album_pictures/",
    playist_pictures:"https://musicisvivid.s3.amazonaws.com/uploads/playlist_pictures/",
    user_uploaded_musics:"https://musicisvivid.s3.amazonaws.com/uploads/user_uploaded_musics/",
    user_contest_music : "https://musicisvivid.s3.amazonaws.com/uploads/user_contest_music/"
   }