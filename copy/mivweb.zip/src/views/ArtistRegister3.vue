<template>
  <div class="homegb">
    <AppHeader></AppHeader>
    <div class="artist-sign-up-container">
      <div class="container">
        <div class="row">
          <div class="artist-sign-up-wraper medium">
            <form action="artist-sign-up-step-4.html" @submit.prevent="validateBeforeSubmit">
              <div class="ar-signup-heading-container">
                <h1>Select Digital Events Genre</h1>

                <p>Please Note This Cannot be Changed Once Profile is Created</p>
              </div>
              <div class="error-cls text-center" v-if="$store.state.registerdata2.errormessage">Please Select Digital Events Genre</div>
              <div class="artist-category-sec">
                <ul class="artist-catagory-ul">
                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="1"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                        v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/alternativ-icon.png">Alternative
                        </p>
                      </span>
                    </label>
                  </li>
                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="2"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                         v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/country-icon.png">Country
                        </p>
                      </span>
                    </label>
                  </li>

                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="3"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                         v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/edm-icon.png">EDM
                        </p>
                      </span>
                    </label>
                  </li>
                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="4"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                         v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/hippop-icon.png">Hiphop-RAP
                        </p>
                      </span>
                    </label>
                  </li>
                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="5"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                         v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/latin-icon.png">Latin
                        </p>
                      </span>
                    </label>
                  </li>
                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="6"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                         v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/pop-icon.png">Pop
                        </p>
                      </span>
                    </label>
                  </li>
                  <li>
                    <label class="digi-check-btn">
                      <input type="radio" 
                      value="7" 
                      v-model="rgisterdata.baseGenreId"
                       name="artist-radio"  
                      v-on:change="changeGenreId(rgisterdata.baseGenreId)">
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/metal-icon.png">Metal
                        </p>
                      </span>
                    </label>
                  </li>

                  <li>
                    <label class="digi-check-btn">
                      <input
                        type="radio"
                        value="8"
                        v-model="rgisterdata.baseGenreId"
                        name="artist-radio"
                        v-on:change="changeGenreId(rgisterdata.baseGenreId)"
                      >
                      <span class="digi-checkmark"></span>
                      <span class="digi-label">
                        <p>
                          <img src="/assets/images/rock-icon.png">Rock
                        </p>
                      </span>
                    </label>
                  </li>
                  <div class="clearfix"></div>
                </ul>
              </div>
              <button class="btn-signin success_msg_btn" type="submit">Continue</button>
            </form>
            <div class="signup3-text">
              Artists; If you have signed up in POP 
                and you don’t qualify with enough Followers 
                for the POP Live section, but your total 
                followers would qualify in the Alternative Genre/ Live section 
                then MiV will move you to the Live Alternative Genre.
            </div>
            <ul class="step-count-ul">
              <li class="active"></li>
              <li class="active"></li>
              <li class="active"></li>
              <li></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <AppFooter></AppFooter>
  </div>
</template>

<script>
import AppHeader from "@/components/UnauthHeader.vue";
import AppFooter from "@/components/ComonFotter.vue";
export default {
  name: "ArtistRegister3",
  props: {
    msg: String
  },
  components: {
    AppHeader,
    AppFooter
  },
  computed: {
    rgisterdata() {
      console.log("this.$store.state.registerdata2",this.$store.state.registerdata2.errormessage)
      return this.$store.state.registerdata2;
    }
  },
  methods: {
    validateBeforeSubmit() {
      this.$validator.validateAll().then(result => {
        console.log("result",result)
        if (result) {
          window.scrollTo(0,0);
          this.$store.commit("artistRgister", this.$store.state.registerdata2);
          //console.log(this.$store.state.registerdata2);
          //this.$store.state.registerstep2 = true;
        } else {
          console.log('err');
        }
      });
    },
    changeGenreId(genreId) {
      if(genreId) {
       this.$store.state.registerdata2.errormessage = ""
      }
    }
  },
  created() {
    this.$store.state.registerdata2 = JSON.parse(
      sessionStorage.getItem("onwatdata")
    );
    this.$store.state.registerdata2.errormessage = ""
  },
  mounted() {
    // window.history.forward(1)
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.signup3-text {
    font-size: 14px;
    justify-content: center;
    padding-top: 15px;
}
.error-cls{
    color: #FFF !important;
    background: #ff605f;
    font-size: 13px;
    padding: 7px 10px;
    border-radius: 5px;
}
</style>
