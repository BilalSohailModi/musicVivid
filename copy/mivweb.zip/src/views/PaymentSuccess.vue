<template>
<div class="text-center">
    <img src="/assets/images/payment-success.png">
</div>
</template>

<script>
import router from '../router';
import { API } from "@/api/api";
export default {
  name: 'PaymentSuccess',
  data() {
   return {
   };
  },
  components: {
 
},
methods:{
},
created(){
},

mounted(){

},

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>