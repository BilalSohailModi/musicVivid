<template>
  <div class="homegb">
    <AppHeader></AppHeader>
    <div class="artist-sign-up-container">
      <div class="container">
        <div class="row">
          <div class="artist-sign-up-wraper medium">
            <form action="artist-sign-up-step-3.html" @submit.prevent="validateBeforeSubmit">
              <div class="ar-signup-heading-container">
                <h1>Create Account</h1>
                <p>Are You an Artist, Want to Share Your Music!</p>
              </div>
              <div class="question-container">
                <h3 class="question-field">Have You Played at Any Festivals Within The Last Year?</h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="1" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">Are You Currently Touring?</h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="2" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">Does your Music Contain Explicit Content?</h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="4" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">Is Music Your Primary Career?</h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="3" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                    <!-- <span class="text-danger"  v-show="isAgre1">{{ "This Field Is Required" }}</span> -->
                  </div>
                </div>
              </div>

              <div class="question-container">
                <h3 class="question-field">
                  Do You Agree That Any Payments From
                  MiV Are Only For The Artist Or Band And
                  Not 3rd Party’s?
                </h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="5" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">
                  Are You The Originator And/Or Hold The
                  Rights To Use The Music You Intend To
                  Upload On MiV?
                </h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="6" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">
                  Is The Copyright Holder For Music You
                  Intend To Use On MiV Registered With BMI,
                  ASCAP, SESAC, Merlin Or Any Other
                  Private Firms?
                </h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input
                        type="checkbox"
                        @click="loggletextare"
                        value="7"
                        v-model="rgisterdata.answers"
                      >
                      <span class="slider round"></span>
                    </label>
                  </div>
                  <textarea
                    v-if="toggle"
                    name="answer"
                    v-validate="'required'"
                    v-model="rgisterdata.copyrightHolder"
                    class="form-control-area mt-10"
                    style="display:block"
                  ></textarea>
                  <span
                    v-show="errors.has('answer')"
                    class="text-danger1"
                  >{{ errors.first('answer') }}</span>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">
                  Do You Agree Not To Use Any Music
                  Owned And Managed By Any Of The
                  Major Music Labels?
                </h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input type="checkbox" value="8" v-model="rgisterdata.answers">
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="question-container">
                <h3 class="question-field">
                  Do You Agree To The
                  <span>
                    <a href="/user-agreement" target="_blank">User Agreement</a>
                  </span>
                  For Music is Vivid (MiV) For Artists?
                </h3>
                <div class="answer-field">
                  <div class="switch-container">
                    <label class="switch">
                      <input
                        type="checkbox"
                        name="agrement"
                        value="9"
                        v-model="rgisterdata.answers"
                        @change="acceptAgreement(rgisterdata.answers)"
                      >
                      <span class="slider round"></span>
                    </label>
                    <span
                      class="text-danger"
                      v-show="isAgre"
                    >To proceed, you must accept the user agreement</span>
                  </div>
                </div>
              </div>

              <div class="social-following-section">
                <label class="label-heading">Combined Social Media Followings</label>
                <ul class="social-following-count">
                  <li>
                    <label class="social-count-radio">
                      <input
                        type="radio"
                        name="radio"
                        value="1"
                        v-model="rgisterdata.socialMediaFollowing"
                      >
                      <span class="social-count-radio-checkmark"></span>
                      <span class="radio-label-text">Under 5K</span>
                    </label>
                  </li>
                  <li>
                    <label class="social-count-radio">
                      <input
                        type="radio"
                        name="radio"
                        value="2"
                        v-model="rgisterdata.socialMediaFollowing"
                      >
                      <span class="social-count-radio-checkmark"></span>
                      <span class="radio-label-text">5K to 100K</span>
                    </label>
                  </li>
                  <li>
                    <label class="social-count-radio">
                      <input
                        type="radio"
                        name="radio"
                        value="3"
                        v-model="rgisterdata.socialMediaFollowing"
                      >
                      <span class="social-count-radio-checkmark"></span>
                      <span class="radio-label-text">100K to 1M</span>
                    </label>
                  </li>
                  <li>
                    <label class="social-count-radio">
                      <input
                        type="radio"
                        value="4"
                        v-model="rgisterdata.socialMediaFollowing"
                        name="radio"
                      >
                      <span class="social-count-radio-checkmark"></span>
                      <span class="radio-label-text">1M +</span>
                    </label>
                  </li>
                </ul>
              </div>
              <button class="btn-signin success_msg_btn" type="submit">Continue</button>
            </form>
            <ul class="step-count-ul">
              <li class="active"></li>
              <li class="active"></li>
              <li></li>
              <li></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <AppFooter></AppFooter>
  </div>
</template>

<script>
import AppHeader from "@/components/UnauthHeader.vue";
import AppFooter from "@/components/ComonFotter.vue";
import router from "../router";
export default {
  name: "ArtistRegister2",
  props: {
    msg: String
  },
  components: {
    AppHeader,
    AppFooter
  },
  data() {
    return {
      user: {},
      geocode: [],
      isAgre: false,
      toggle: false
      // isAgre1:false
    };
  },
  computed: {
    rgisterdata() {
      return this.$store.state.registerdata2;
    }
  },
  methods: {
    loggletextare() {
      this.toggle = !this.toggle;
      console.log(this.toggle);
    },
    acceptAgreement(value) {
      if (value.length) {
        this.isAgre = false;
      } else {
        this.isAgre = true;
      }
    },
    validateBeforeSubmit() {
      this.$validator.validateAll().then(result => {
        if (result) {
          var arr = ["0", "0", "0", "0", "0", "0", "0", "0", "0"];
          this.$store.state.registerdata2.answers.map((e, index) => {
            arr[e * 1 - 1] = "1";
          });

          console.log(arr[2]);
          if (arr[8] == 0) {
            console.log("arr[8]", arr[8]);
            this.isAgre = true;
          }
          //  else if(arr[2] ==0){
          //        this.isAgre1 = true;
          //  }
          else {
            this.$store.state.registerdata2.answers = arr;
            sessionStorage.setItem(
              "onwatdata",
              JSON.stringify(this.$store.state.registerdata2)
            );
            router.push({
              name: "ArtistRegister3"
            });
          }

          //this.$store.state.registerstep2 = true;
        }
      });
    }
  },
  created() {
    this.$store.state.registerdata2 = JSON.parse(
      sessionStorage.getItem("onwatdata")
    );
  },
  mounted() {
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

