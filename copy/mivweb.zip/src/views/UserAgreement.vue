<template>
<div>
  <div v-if="user">
 <AppHeader></AppHeader>
  </div>
<div class="agreement-text">
<h2 class="western" align="center"><span style="font-size: large;"><u>User Agreement for Music is Vivid (MiV)</u></span></h2>
<h2 class="western" align="center"><span style="font-size: large;"><u>For Independent Musicians and Artists </u></span></h2>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u><strong>Music is Vivid (MiV) is: a Music Competition app. </strong></u></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em>There are numerous Music is Vivid (MiV) Artist benefits such as financial and fan exposure, however, this document&rsquo;s only purpose is to detail our terms of use for artists and Music is Vivid who are accepted and active in the Live and Draft Competition sectors and the Artist Que of the APP and website. </em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u><strong>When you apply for a competition position in the Live, Draft or Que at Music is Vivid you agree to the Terms and Conditions as listed and without exception: This &ldquo;User Agreement for Music Is Vivid (MiV) for Musicians and Artists&rdquo;;</strong></u></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u><strong>It Is Important to Note:</strong></u></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong>MiV is a Music Competition site and payouts are earned by the Artists in the Live Artist section only. Earnings and payouts for Live Artists participants are based solely upon competition results. Artists in the Draft and Artist Que are on the site for the sole purpose of promotion of their music and musical capabilities and for the opportunity of progressing to the Live Artists Section. Draft and Que artists are not earning any financial payouts. The point of the Competition earnings is the potential to hopefully provide a meaningful earnings opportunity not tied to streaming earnings. </strong></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong>Make sure you understand: MiV is a music competition and artist promotion site and is Not a steaming service. MiV does </strong></em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u><strong>Not</strong></u></em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong> pay any streaming pay-out or separate fees for use of your music and/or videos played in the competitions or on the site itself. As described above, MiV pays a financial payout based on your Competition ranking and provides a site for artist promotion and fan exposure. If you have registered songs and video copyright and wish to be paid separately for those rights then please see the </strong></em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u><strong>Financial Payout and Reporting</strong></u></em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong> section. </strong></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong>Do not sign-up if you have any expectation of receiving any payment for streaming your music. </strong></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong>MiV is for Independent Artists and if you are signed by a major label please do not sign up at MiV. The &ldquo;artist&rdquo; is to sign on and upload their contest songs/videos and MiV pays the artist based on the artist ranking in the Live section genre they are competing in. If the artists is contracted with support and other professionals and managers, music engineers (for example) the artists is required to pay for their own services directly.</strong></em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong>In each section of Live and Draft, there is a limited number of 240 artists slots and only 8 Genres. The Live and Draft sections are mirror images so being featured in Competitions means the fan exposure is the same. In the 3-artists Contest you will be featured approximately 24 times and if you progress to the 2-person tournaments another approximately 40 + of Features. The limited number of slots or positions means more Fan exposure and features, plus greater earning potential for the Artists. Fans are 100% in charge of voting. Also, the initial seeding for qualified applicants is based on our verified Artist Fan Following. The strength and size of your Fan base is quite important. Only fan Members Vote (currently the Member cost is $3.99 per month) and this is, in our opinion, the best and most transparent way to make results legitimate. </strong></em></span></span></span></span></p>


<p><u><strong>2020 Digital Upload Support </strong></u></p>
<p>Artist who signs up directly with MiV will receive a $300 allowance for digital upload support. This is a one-time payment for the 2020 year only. This is limited for those artists who are in the LIVE competition section. To qualify the artist must have signed up directly here and have participated in one contest in the<u><strong> Live</strong></u> section in 2020. The payment will be paid at the same time as the artists earnings are paid out. MiV reserves the right to create one payment for contest earnings and the $300 digital upload support.</p>
<p>Artists Digital Upload; If the Artist&rsquo;s aggregator or label is not signed-up with MiV then MiV and artist will have content uploaded as follows. Artist will upload music and videos where feasible but, may request MiV to upload music and videos from the following locations; _____________________________________ Be exact with the address</p>
<p>_____________________________________</p>
<p>Artist agrees that MiV has discretion to upload music and videos from the site artist has provided. Artist also agrees that MiV is authorized to upload content of songs and videos from sites MiV deems appropriate.</p>
<p><a name="_GoBack"></a> Artist agrees that artist will either continue to upload content directly or will direct their aggregator or label to upload their future work to MiV.</p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Terms of Use; Contract</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Music is Vivid (MiV); When you use our Services you agree to all of these terms. Your use of our Services is also subject to our Cookie Policy and our Privacy Policy, which covers how we collect, use, share, and store your personal information.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You agree that by clicking &ldquo;Join Now&rdquo;, &ldquo;Submit Your Resume&rdquo;, &ldquo;Join Music Is Vivid&rdquo;, &ldquo;Sign Up&rdquo; or similar, registering, accessing or using our services (described below), you are agreeing to enter into a legally binding contract with Music Is Vivid (even if you are using our Services on behalf of an Industry, Fan, or Artist). If you do </span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u>not</u></em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"> agree to this contract (&ldquo;Contract&rdquo; or &ldquo;User Agreement&rdquo;), do not click &ldquo;Join Now&rdquo; (or similar) and do not access or otherwise use any of our Services.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Your use of our Services is also subject to our Privacy Policy and Cookie Policy; includes all other MiV related services or products such as a MiV store, personal information you provide, personal Information, password and posted content such as resume&rsquo;s, music and your related story, music, and promotional videos. </span></span></span></span></p>
<p>&nbsp;</p>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><u><strong>Independent Musician Sign Up Policy And Terms Of Use</strong></u></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: medium;"><u><strong>;</strong></u></span></span></span></p>
<p>&nbsp;</p>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The MIV (Site for Independent Artist) has a limited number of Artists and Musician competitive positions available on the Live Site and the Draft Site and the Que. This limited number means more Artist exposure and opportunity for the Artist to develop a larger and more engaged fan base. The number of artists participating, qualifications for acceptance in either the Live or the Draft or Que, and the contest Member voting rules for either category is at the sole discretion of MiV. </span></span></span></p>
</li>
</ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">User Agreement is deemed accepted and agreed upon by you if you submit a Bio and About information, a music video and other music links to your music list. MiV will review your submittal and determine, under our sole discretion, if we accept your submittal and agree to post you and your music on Music is Vivid. Please note, that you are required to select your competition songs and or videos for uploading.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Once you sign up and based on your verified Fan Following, MiV may automatically enter your music, story and/or promotional video into our &ldquo;Open Music Genre Digital Competition Events&rdquo; and either in the Live, Draft or Que artist sections. In the Active Competition sections of Live and Draft. In the Live and Draft sections, fans will hear your music, story and/or promotional video. The progressive Competition is called a Series, which includes; Contests (3 artist contests) and Tournaments (2 artist contests). Fan (Member) voting in the progressive Tournaments will determine your rank (the Leaderboard Rank) and final financial payout.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">MiV (based on Fan/Member voting) automatically enters you into all of your qualified progressive voting contests. Once you have been entered into any of our progressive Contests and Tournaments your Video submittal and music participation is required for that Competition and you cannot leave the Competition nor have your contest music and or video removed and permanently deleted. However, MiV reserves the right to have any inappropriate or illegal music removed from a Series at any time. If that happens you will be asked to use other, appropriate music to continue in the contest. Note, when you sign-up you have three video and/or songs that you can upload for the Contests. You may change or delete any of these selections at any time, as long as three entries are not exceeded. For your optimum results (and earnings) make sure you do not post inappropriate music to the competition as delays will probably affect exposure and voting. </span></span></span></p>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If you wish to opt out; Once a Series has been completed and if you determine you do not want to participate in any other Series Contest then you may opt out from the next Series and consequently from the MiV site. We must receive your Opt Out written and dated and &ldquo;Your&rdquo; signed letter at least 5 days in advance of the next Series Competition. The written message must be from the Artist or band member used in the sign-up process and received by MiV by registered postal service or by email at: </span></span></span><a href="mailto:admin@musicisvivid.com"><span style="font-family: Arial, serif;"><span style="font-size: small;">admin@musicisvivid.com</span></span></a><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">, and please include Artist Opt Out in the subject heading. The Opt out becomes official with our acknowledgement. We will forward an acknowledgement of your opt out. All your information on the site will be deleted. You will still be eligible for any money earned in the Series you or your band participated in. You are not do any other payment or compensation except that earned in the Live section you participated in. </span></span></span></p>
</li>
</ul>
</li>
</ul>
<p>&nbsp;</p>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;">Financial Payout and Reporting;</span></span></p>
</li>
</ul>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If you have fully participated in a series (Contests and Tournaments) and qualified for a financial payout the check drawn on a U.S. Bank will be mailed, wired or provided in a legal form and method by MiV. Payment will be made upon the close of a Series and distributed within 30 working days from the series closing date. The payment will be made to the person or persons, or entity submitted to MiV and on file at MiV. </span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u>If you are registered as the song rights holder and/or the performance rights holder for songs and videos used on the site then you acknowledge that the payment to you for the competition winnings includes a sum for the copyright song use and/or performance rights for any video used. If you wish to have the amount separated it is your responsibility to notify us in writing by registered letter with proper instructions and tax reporting information</u></em></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">. We will deduct 5% or more from your competition earnings for your copyright and performance right fees. If you are in the Draft or Que then you acknowledge that performance rights and music copyrights used on MiV is done strictly for promotion purposes and no sum due you or payment to you for the use of use of your videos and music.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">There will be about </span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>2 Series</u></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> per 13+ months. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The proper tax reporting forms and legal entity information must be on file at MiV. Such distribution thus can occur only if registered/winning artists have on file a legal 1099, or W 9 document tax (example for entities of the United</span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"> States) or </span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Country of origin form. Registered artist agrees that payment designee is valid and legal and all payments for taxes, services, agents, managers and co-artists are the sole responsibility of the registered artist entity.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Only the Live section qualifies for financial payout. The Live section payout is for all Live (8) genre competition artists based on the in-genre final ranking plus the qualified copyright holders of their music. The overall financial sum available for the 8 Live section genres is a percentage of the member Subscriber monthly net revenue (after credit card charges). Each Live genre may receive an equal share of the total artist fund. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">One of the Main MiV goals is to be a platform that can provide meaningful financial opportunities for Independent Artists. The Series 1 and Series 2, which approximates 12 months; the payout schedule would provide up to $15 million US. This is based on a </span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>monthly</u></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> Member subscriber base of 2 million paying Members at $3.99 for a full 13 months. The payout sum is for the Live Contestants for 2 Series, over approximately 13 months and is the sum to be divided among the 8 genres in the Live section (only). Please note, as stated, the total artist payout is based on 2 Million Members fully subscribed for each of the 13 months. For example, if in the first three months the number of Members is only 300,000 total then the average monthly Members could be lower than the 2 million average thus lowering the payout available. Conversely, if the subscribing members increase, then, of course, the payout would be proportionately higher. If the user base for Series 2 is higher than Series 1 then the total payout for Series 2 would be higher. Each Series is computed as a discreet event. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"> <span style="font-family: Arial, serif;"><span style="font-size: small;">Once we have history we can publish actual payout totals and individual slotted payout for artists. There is no fee or cost to artists for signing up. Each month a percentage of net revenue less credit card costs is applied and paid to the MiV Artist Bank Account before any other costs, expenses, salaries or fees are taken. MiV has no debt or finance costs. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">It is the sole discretion of MiV as to the rules for the Competition and the financial formula for total payout and individual payout based on final ranking. MiV also reserves the right to adjust the payout between genres if in MiV&rsquo;s opinion market conditions and fan participant so warrants adjustments. Any changes to payout formulas can be made but only after a Series is completed. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"> <span style="font-family: Arial, serif;"><span style="font-size: small;">MiV may, at its sole discretion, make adjustments to total money paid to a Genre based on subscribing members of that genre compared to the number of subscribing members for the other genres. Only the Member/subscribers can vote and as such determine Series (Live Contest/Tournament) outcomes and rankings. Note, MiV does not vote or use MiV judges to vote to determine contest results. The Member /subscribers represent 100% of Artist voting (and thus financial payout). However, if you have broken a MiV policy, such as using unauthorized music, or broken other policies then at MiV&rsquo;s sole discretion MiV may cancel you from the contest and any subsequent financial payout for that Series.</span></span></span></p>
</li>
</ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Competition Rules</strong></u></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">;</span></span></span></p>
</li>
</ul>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>How Competition Works</strong></u></span></span></span></p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">There are two Artist Competition Sections; Live and Draft</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">There are 8 Genres, and 240 artists total </span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>in each genre</u></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> in Live and Draft. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Live and Draft Competitions sections are Mirror images of each other.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">In the first Competition, Artists are seeded in Live and Draft based on their total number of Fan Following. The lowest seeded Artist in Live is higher than the top seeded artist in Draft. Seeding is 100% decided by Fan following. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The difference for Live is that artists earn pay-out based on competition results. Draft is for Artists gaining traction and building Fan Following. The Draft Artist goal is to place high in their genre competition and possibly be seeded to the Live Section Competition. All Competition Results are decided 100% by </span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>Member</u></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> Fan Voting. (An artist may become a member by signing up and as a subscriber and thereby may vote in all contests).</span></span></span></p>
</li>
</ul>
</ul>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Competition Overview </strong></u></span></span></span></p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The first Competition is called Series 1. A Competition consists of Contests and Tournaments. A In Contests 3 artist compete and Member/Fans vote for 1</span></span></span><span style="color: #000000;"><sup><span style="font-family: Arial, serif;"><span style="font-size: small;">st</span></span></sup></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">, 2</span></span></span><span style="color: #000000;"><sup><span style="font-family: Arial, serif;"><span style="font-size: small;">nd</span></span></sup></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> and 3</span></span></span><span style="color: #000000;"><sup><span style="font-family: Arial, serif;"><span style="font-size: small;">rd</span></span></sup></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">. Voting is 70% based on the contest and 30% (10 each) for followers, likes and luv. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The first Contest starts with 240 Artists, in each genre, who compete-in two rounds-to determine the top 96 slots,</span></span></span></p>
</li>
</ul>
</ul>
<p>&nbsp;</p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Then the Top 96 compete for the top 32 slots. </span></span></span></p>
</li>
</ul>
</ul>
<p>&nbsp;</p>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>TOURNAMENT STARTS with Top 32 Artists (per genre-Live and Draft)</strong></u></span></span></span></p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">There are two small changes when the Tournament starts; 1. There are two Artist competing and 2. Voting is One Vote for First Place. Everything else is the same.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Tournament starts with Top 32 to decide top 16</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Then Top 16 compete for Top 8 Artists</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Then Top 8 compete for Top 4 Artists</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Then Top 4 compete for Top 2 Artists</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Finals decide # 1 and # 2.</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The Final 8 from Series 1 Are Now Qualified to Advance to a final Playoff (versus the top 8 from Series 2). </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">This Concludes the First Series Competition. A countdown clock starts in preparation for Series 2. Some Draft artists are eligible to move to the Live section based on fan votes and fan following. However, the number of contestants per genre will not exceed 240. </span></span></span></p>
</li>
</ul>
</ul>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Series 2</strong></u></span></span></span></p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Series 2 now starts. Series 2 is a mirror image of the Series 1. It starts with the same number in each genre which is up to 240 artists. Contests and the Tournament structure is exactly the same. Artist that carry over to Series 2 will carry over their follower number only and All other scoring and voting resets. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If MiV concludes that there could be a Playoff between the Top 8 finalist, in every genre, Live and Draft from Series 1 versus Series 2 Top 8. Then MiV will post the rules and earning payout possibilities. </span></span></span></p>
</li>
</ul>
</ul>
<p><a name="_GoBack"></a> <span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Some Details:</strong></u></span></span></span></p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">All 240 Artists Live and Draft compete in one of the 8 genres (Alternative, Country, EDM, Latin, Hip Hop/Rap, POP, Metal, Rock). Artist may compete in One genre only. Artist may up-load up to three songs and or videos for the competition. The selection may be changed by the artist anytime, but cannot exceed the three choices. Artist may also upload one &ldquo;my story&rdquo; video. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">A New Contest Starts every 30 minutes in </span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><strong>Each</strong></em></span></span></span><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> genre in Live and Draft (mirror image).</span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">So there are 16 New (3-artist) Contests every 30 minutes, (8 genres in Live and 8 genres in Draft). Members can vote in any and all genre contests, but only one vote per contest in the 24 hour cycle. </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Every 30 minute voting segment is repeated 3 times or once per 8 hours for 24 hours (world clock, therefor, fair for all) </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">There are 2 Rounds of 240 competing artists to get to the Top 96 artists. The top 96 artists also compete in a 3 artist contest to determine Top 32 artists per genre (Live and Draft). </span></span></span></p>
</li>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">All Contest Voting is; 3 artists compete in a 30 minute segment. Voting stops after 27 minutes. Artist score is based on; The Contest is worth 70%, and Fan Likes, Love and Followed is worth 10% each. Once Voting is submitted then the vote is final. </span></span></span></p>
</li>
</ul>
</ul>
<p>&nbsp;</p>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Notice to Artists and Users </strong></u></span></span></span></p>
<ul>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Apple nor its affiliates or any other entity except Music is Vivid LLC is involved in any way with the MiV contests, payouts and competition. </span></span></span></p>
</li>
</ul>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Moving from Draft to Live and back from Live to Draft;</span></span></span></p>
<ul>
<li>
<p><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;">All artists in the Live and draft will have a ranking based on Member voting during the Contests and Tournaments. The Top 30 draft ranked contestants have the opportunity to move to the Live Section, if the number of Fan Followers is large enough to replace the bottom 30 ranked live contestants. MiV will monitor this process and must approve the final process and movement. Since each genre is currently fixed at 240 participants the &ldquo;replaced&rdquo; Live contestants move to the Draft, where they can requalify in the next Competition series. </span></span></span></p>
</li>
</ul>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">As a registered Artist Member you are considered account holders. You agree to: (1) try to choose a strong and secure password; (2) keep your password secure and confidential; (3) not transfer any part of your account (e.g., connections) and (4) follow the law and our list of Dos and Don&rsquo;ts. You are responsible for anything that happens through your account unless you close it and so notify Music is Vivid. Be aware, when you share information, others can see, copy and use that information.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Our Services allow messaging and sharing of information in many ways, such as Your; Profile, Posted Musician Resume, Agents and Agencies, fan and site visitors, links to news articles, Venue participation, our site Musical contests, and blogs. There are </span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em>&ldquo;no&rdquo;</em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"> current Information and content restrictions or blocking mechanisms available by Music is Vivid on our site or app. Restrictions must be done by site participants through their own email, web site and social media account sites. </span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The Site Musician Sign- Up Resume; By completing and uploading the information for the &ldquo;Resume&rdquo; the artist understands that the information will be shared with site fans, visitors, musicians and Agency individuals and Agency business without restriction. Musicians will post their selected music via the Resume for public listening. Music is Vivid may randomly select Musicians, bands, genre&rsquo;s for site contests and fan viewing/listening without restriction. Some contest results may be automatically posted to the Musicians resume. We will also post Resume information and link to other site categories, for example, Map location venues, biography of the musician, without restriction. </span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We are not obligated to publish any information or content on our Service and, at our sole discretion, can remove your information and content, without notice</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;">As between you and others, including musical group members, agency partners, for example, the site account belongs to the entity, group or individual that registered. </span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Rights and Limits</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><strong>Your License to Music Is Vivid:</strong></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You own all of the content, feedback, and personal information you provide to us, but you also grant us a non-exclusive license to use any or all this information on the MiV site. </span></span></span></span></p>
<h3 class="western"><span style="color: #333333;"><span style="font-family: Arial, serif;"><u>Public Performance License Obligations;</u></span></span></h3>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #333333;"><span style="font-family: Arial, serif;"><span style="font-size: small;">A public performance license is an agreement between a music user and the owner of a copyrighted composition (song) that grants permission to play the song in public, online, or on radio. This permission is also called public performance rights, performance rights, and performing rights.</span></span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Whether you have written or use a song writer for your music you must notify us who has the published rights to the music that you use on our site. You must include in your sign up and keep the record of any music that you use on our site and the holder of the &ldquo;published rights&rdquo;. This would include the publisher management firm (if any) such as BMI, ASCAP SESAC and Merlin and any other private firm(s). You are, however, prohibited from using any music owned and managed which you do not have a right and/or license to perform. </span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Arial, serif;"><span style="font-size: small;">Please provide the name of the person(s) or entities or if applicable one of the publisher services listed above that have a copyright license for any songs you intend to use on the MiV service. This can be done in the Artist sign up form. Please do not apply if you are signed with a major label and/or if you use any major label performance or mechanical copyrighted music. </span></span></p>
</li>
<li>
<p><span style="font-family: Arial, serif;"><span style="font-size: small;">MiV has the right and intends to reserve from the artist payout a percentage of that payout that may be required for copyright or &ldquo;public performance license&rdquo;. That reserve is designated now to be 5% of projected payout. </span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If you are the song rights holder the payment to you for the competition winnings will include a sum for the copyright use. If you wish to have the amount separate it is your responsibility to notify us in writing (via e-mail) proper instructions and tax reporting information.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You promise to only provide information and content that you have the right to share, and that your Music is Vivid profile will be truthful. If for any reason, you have been a party to a legal action regarding copyright, trademark or intellectual use of your music which you have posted on MiV, then you will hold MiV harmless from any such legal proceedings.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">As between you and Music is Vivid, provided that </span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><strong>you own the rights to the music content and information</strong></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"> that you submit or post to the services and you are only granting Music is Vivid and our affiliates the following non-exclusive license: </span></span></span></span></p>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">A worldwide, transferable and sub-licensable right to use, copy, modifies, distribute, publish, and process, information and content that you provide through our services, without any further consent, notice and/or compensation to you or others. These rights are limited in the following ways:</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You can end this license for specific content by closing your account. You will provide notice by email to MiV that you are closing your account. MiV will remove your current content from the site but this does not include music that already been downloaded into Fan playlists. (See Termination Details For More Information)</span></span></span></span></p>
</li>
</ul>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We may include your MiV content in advertisements for the products and services of third parties to others without your separate consent (including sponsored content). </span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We will get your consent if we want to give third parties the right to publish your posts beyond the service. However, other Members and/or Visitors may access and share your content and information, consistent with your choices.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">While we may edit and make formatting changes to your content (such as translating it, modifying the size, layout or file type or removing metadata), we will, make our best effort, not to modify the meaning of your expression.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Because you own your content and information and we only have non-exclusive rights to it, you may choose to make it available to others, including under the terms of a Creative Commons license. </span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You agree that we may access, store, and use any information that you provide in accordance with the terms of the Privacy Policy.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">By submitting suggestions or other feedback regarding our Services to Music is Vivid, you agree that Music is Vivid can use and share (but does not have to) such feedback for any purpose without compensation to you</span></span><span style="font-family: Arial, serif;"><span style="font-size: small;">. </span></span></span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Service Availability</strong></u></span></span></span></span></p>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We may change, suspend or end any Service, or change and modify Site prices prospectively in our discretion. To the extent allowed under law, these changes may be effective without notice to you. We may change or discontinue any of our Services. We are not obligated or required to store or keep showing any information and content that you&rsquo;ve posted.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Music is Vivid is not a storage service. You agree that we have no obligation to store, maintain or provide you a copy of any content or information that you or others provide, except to the extent required by applicable law and as noted in our Privacy Policy.</span></span></span></span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-family: Arial, serif;"><span style="font-size: small;">Any continuation of Series Contests and the Series Contest payout is a voluntary act by MiV but not a guarantee. It is the sole responsibility of the Artist and/or Musician for any </span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em>expense associated with the development of their music and including, but not limited to;</em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"> video development, posting, and music content and development, education and professional services including, but not limited to, those that MiV provides access to. MiV does not allow the use of its name, trademarks or copyright with any Artist promotion of its music, marketing and video presentations. At its sole discretion, MiV may voluntarily provide gifts and/or monetary rewards to the Musician, but providing any gift and or monetary reward does not imply any contractual event between MiV and the Artist/Musician. </span></span></p>
</li>
</ul>
<p><br /><br /></p>
<ul>
<li>
<p><span style="font-family: Arial, serif;"><span style="font-size: small;">You will not share an account with anyone else and will follow our rules as well as the law. </span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Music Is Vivid Terms of Use - continued; (&ldquo;Dos&rdquo; and &ldquo;Don&rsquo;ts&rdquo;)</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>You agree that you will</strong></u></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><strong>:</strong></span></span></span></span></p>
<ol type="a">
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Comply with all applicable laws, including, without limitation, privacy laws, licensing, copyright and intellectual property laws, anti-spam laws, export control laws, tax laws, and regulatory requirements;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Provide accurate information to us and keep it updated;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use your real name, and picture, on your profile;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use the Services in a professional manner.</span></span></span></span></p>
</li>
</ol>
<p>&nbsp;</p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>You agree that you will&nbsp;</strong></u></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em><u><strong>not</strong></u></em></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>:</strong></u></span></span></span></span></p>
<ol>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Act in an unlawful or unprofessional manner in connection with our Services, including being dishonest, abusive or discriminatory;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Post inaccurate, defamatory obscene, shocking, hateful, explicit, threatening or otherwise inappropriate content or airing personal grievances or disputes;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use an&nbsp;</span></span><a href="https://linkedin.com/help/linkedin/answer/430?lang=en"><span style="font-family: Arial, serif;"><span style="font-size: small;"><strong>image</strong></span></span></a><span style="font-family: Arial, serif;"><span style="font-size: small;">&nbsp;that is not your likeness or a head-shot photo for your Resume profile;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Create a false identity on Music is Vivid. The occasional creation of clearly fictional profiles by Music is Vivid or with its express permission in connection with a promotional campaign does not waive this obligation;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Misrepresent your identity (e.g. by using a pseudonym), your current or previous positions, qualifications or affiliations with a person or entity;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Create a Member profile for anyone other than yourself (a real person);</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Claim that you have appeared at any venue, concert or event that is not accurate and verifiable;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use or attempt to use another's account;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Harass, abuse or harm another person;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Send or post any unsolicited or unauthorized advertising, &ldquo;junk mail,&rdquo; &ldquo;spam,&rdquo; &ldquo;chain letters,&rdquo; &ldquo;pyramid schemes,&rdquo; or any form of solicitation unauthorized by Music Is Vivid;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Develop, support or use software, devices, scripts, robots, or any other means or processes (including crawlers, browser plugins and add-ons, or any other technology or manual work) to scrape the Services or otherwise copy profiles and other data from the Services;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Bypass or circumvent any access controls or Service use limits (such as caps on keyword searches);</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Copy, use, disclose or distribute any information obtained from the Services, whether directly or through third parties (such as search engines), without the consent of Music is Vivid;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Solicit email addresses or other personal information from Members you don&rsquo;t know, without authorization.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use, disclose or distribute any data obtained in violation of this policy;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Disclose information that you do not have the consent to disclose (such as confidential information of others);</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Violate the intellectual property rights of others, including copyrights, patents, trademarks, trade secrets, or other proprietary rights. For example, do not copy or distribute (except through the available sharing functionality) the posts or other content of others without their permission, which they may give by posting under a Creative Commons license; lyrics yourself?</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Violate the intellectual property or other rights of Music Is Vivid, including, without limitation, (i) copying or distributing our learning videos or other materials or (ii) copying or distributing our technology, unless it is released under open source licenses; (iii) using the word &ldquo;Music is Vivid&rdquo; or our logos in any business name, email, or URL except as provided;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">se Music is Vivid invitations to send messages to people who don&rsquo;t know you or who are unlikely to recognize you as a known contact;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Post anything that contains software viruses, worms, or any other harmful code;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Manipulate identifiers in order to disguise the origin of any message or post transmitted through the Services.</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Create profiles or provide content that promotes escort services or prostitution, foul language or language of sexual content, harmful language, violent language of any kind:</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Create or operate a pyramid scheme, fraud or other similar practice;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Reverse engineer, decompile, disassemble, decipher or otherwise attempt to derive the source code for the Services or any related technology that is not open source;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Imply or state that you are affiliated with or endorsed by Music is Vivid without our express consent (e.g., representing yourself as an accredited Music is Vivid member);</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Rent, lease, loan, trade, sell/re-sell access to the Services or related data;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Sell, sponsor, or otherwise monetize any Service without Music is Vivid&rsquo;s consent;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Deep-link to our Services for any purpose other than to promote your profile or a Group on our Services, without Music is Vivid&rsquo;s consent;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Remove any copyright, trademark or other proprietary rights notices contained in or on our Service;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Remove, cover or obscure any advertisement included on the Services;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use bots or other automated methods to access the Services, add or download contacts, send or redirect messages;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Monitor the Services&rsquo; availability, performance or functionality for any competitive purpose;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Engage in &ldquo;framing,&rdquo; &ldquo;mirroring,&rdquo; or otherwise simulating the appearance or function of the Services;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Overlaying or otherwise modifying the Services or their appearance;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Access the Services except through the interfaces expressly provided by Music is Vivid, such as its mobile applications, musicisvivid.com and slideshare.net;</span></span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Use a Service for tasks that it is not intended for</span></span><span style="font-family: Arial, serif;">;</span></span></span></p>
</li>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Override any security feature of the Services;</span></span></span></span></p>
</li>
</ol>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Other Content, Sites and Apps</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Your use of others&rsquo; content and information posted on our Services is at your own risk.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Others may offer their own products and services through Music is Vivid, and we aren&rsquo;t responsible for those third-party activities. </span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">By using the Services, you may encounter content or information that might be inaccurate, incomplete, delayed, misleading, illegal, offensive or otherwise harmful. Music is Vivid generally does not review content provided by our Members or others. You agree that we are not responsible for others&rsquo; (including other Members&rsquo;) content or information. We cannot always prevent this misuse of our services, and you agree that we are not responsible for any such misuse. You also acknowledge the risk that you or your organization may be mistakenly associated with content about others when we let connections and followers know you or your organization were mentioned in the news</span></span><span style="font-family: Arial, serif;"><span style="font-size: small;">.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Limits</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We have the right to limit how you connect and interact on our Services.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Music is Vivid reserves the right to limit your use of the Services, including the number of your connections and your ability to contact other Members. Music is Vivid reserves the right to restrict, suspend, or terminate your account if Music is Vivid believes that you may be in breach of this Contract or law or are misusing the Services (e.g. violating any Do and Don&rsquo;ts). </span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Intellectual Property Rights</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We&rsquo;re providing you notice about our intellectual property rights.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Music is Vivid reserves all of its intellectual property rights in the Services. Using the Services does not give you any ownership in our Services or the content or information made available through our Services. Trademarks and logos used in connection with the Services are the trademarks of their respective owners. Music is Vivid, logos and other Music is Vivid trademarks, service marks, graphics, and logos used for our Services are trademarks or registered trademarks of Music is Vivid. </span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><em>We are providing notice that we use Icons and Graphic inspiration made with and from Logomakr.com.</em></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Termination</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Music is Vivid may terminate this Contract at any time without cause. If you terminate our contract you must do so by email to; info@musicisvivid.com. However, your termination of content can only happen after a Series Contest is completed. We must receive your termination five days before the next Series Competition starts. Since our Competitions are automated this timing is necessary so as not to unduly disrupt the completion of the other artists. At the time of effective receipt MiV will have 10 business days to remove your content from the site. On termination, you lose the right to access or use MiV Services. MiV is under no obligation to return, by electronic or mail services any content or information that you provided MiV. MiV will simply delete all information received from you. If you terminate you lose any further rights to future contest results and payouts. MiV will remove your current content from the site but this does not include music that already been downloaded into Fan playlists.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">The following shall survive termination:</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Once you have been entered into any of our progressive Contests and Tournaments your Video submittal and music participation is required for that Series and you cannot have your contest music video removed or deleted while the Series is on-going.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Our rights to use and disclose your feedback;</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Members and/or Visitors&rsquo; rights to further re-share content and information you shared through the Service to the extent copied or re-shared prior to termination;</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Any amounts owed by either party prior to termination remain owed after termination</span></span><span style="font-family: Arial, serif;"><span style="font-size: small;">.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Dispute Resolution</strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">In the unlikely event we end up in a legal dispute;</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Any United State or foreign citizens and/or entities disputes relating to this disclaimer shall be subject to the exclusive jurisdiction of the courts of Florida, USA. Any disputes are to be adjudicated in Orlando, Florida as Binding Mediation and shall be conducted according to rules of practice and procedure adopted by the Supreme Court of Florida.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">For all, including those who live outside of the United States, you agree that the laws of the State of Florida, U.S.A., excluding its conflict of laws rules, shall exclusively govern any dispute relating to this Contract and/or the Services. Each party is responsible for their own attorney fees, court costs and administrative and personal costs related to the matter under dispute.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If a court with authority over this Contract finds any part of it not enforceable, you and us agree that the court should modify the terms to make that part enforceable while still achieving its intent. If the court cannot do that, you and MiV agree to ask the court to remove that unenforceable part and still enforce the rest of this Contract. To the extent allowed by law, the English language version of this Contract is binding and other translations are for convenience only. This Contract (including additional terms that may be provided by us when you engage with a feature of the Services) is the only agreement between us regarding the Services and supersedes all prior agreements for the Services.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If we don't act to enforce a breach of this Contract that does not mean that Music is Vivid has waived its right to enforce this Contract. You may not assign or transfer this Contract (or your membership or use of Services) to anyone without our consent. However, you agree that Music is Vivid may assign this Contract to its affiliates or a party that buys it without your consent. There are no third party beneficiaries to this Contract.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We reserve the right to change the terms of this Contract and will provide you notice if we do and we agree that changes cannot be retroactive. If you don't agree to these changes, you must stop using the Services.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You agree that the only way to provide us legal notice is at the addresses provided in below.</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"> Music is Vivid, 5401 S. Kirkman Rd ste 310 , Orlando, FL 32819-7937</span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>No Warranty</strong></u></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>; </u></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;"><u><strong>Exclusion of Liability </strong></u></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;"><u><strong>These are the limits of legal liability we may have to you.</strong></u></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;">TO THE EXTENT PERMITTED UNDER LAW (AND UNLESS MUSIC IS VIVID HAS ENTERED INTO A SEPARATE WRITTEN AGREEMENT THAT OVERRIDES THIS CONTRACT), MUSIC IS VIVID AND ITS AFFILIATES (AND THOSE THAT MUSIC IS VIVID WORKS WITH TO PROVIDE THE SERVICES) SHALL NOT BE LIABLE TO YOU OR OTHERS FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL OR PUNITIVE DAMAGES, OR ANY LOSS OF DATA, OPPORTUNITIES, REPUTATION, PROFITS OR REVENUES, RELATED TO THE SERVICES (E.G. OFFENSIVE OR DEFAMATORY STATEMENTS, DOWN TIME OR LOSS, USE OF, OR CHANGES TO, YOUR INFORMATION OR CONTENT).</span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;">IN NO EVENT SHALL THE LIABILITY OF MUSIC IS VIVID AND ITS AFFILIATES (AND THOSE THAT MUSIC IS VIVID WORKS WITH TO PROVIDE THE SERVICES) EXCEED, IN THE AGGREGATE FOR ALL CLAIMS, AN AMOUNT THAT IS THE LESSER OF (A) FIVE TIMES THE MOST RECENT MONTHLY OR YEARLY FEE THAT YOU PAID FOR A SUBSCRIPTION SERVICE, IF ANY, OR (B) US $100.</span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;">THIS LIMITATION OF LIABILITY IS PART OF THE BASIS OF THE BARGAIN BETWEEN YOU AND MUSIC IS VIVID AND SHALL APPLY TO ALL CLAIMS OF LIABILITY (E.G. WARRANTY, TORT, NEGLIGENCE, CONTRACT, LAW) AND EVEN IF MUSIC IS VIVID OR ITS AFFILIATES HAS BEEN TOLD OF THE POSSIBILITY OF ANY SUCH DAMAGE, AND EVEN IF THESE REMEDIES FAIL THEIR ESSENTIAL PURPOSE.</span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="font-family: Arial, serif;">SOME LAWS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY, SO THESE LIMITS MAY NOT APPLY TO YOU.</span></span></span></p>
<h2 class="western"><br /><br /></h2>
<h2 class="western"><span style="font-size: medium;"><u>Music is Vivid Privacy and Cookies Policy Statement </u></span></h2>
<p align="center"><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><em><span style="font-family: Arial, serif;"><span style="font-size: small;"><strong>We are committed to privacy and security for all of our customers.&nbsp; Because we respect your right to privacy, we have developed a Privacy Statement as indicated below.</strong></span></span></em></span></span></p>
<h3 class="western"><br /><br /></h3>
<h3 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><u>YOUR INFORMATION:</u></span></span></h3>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If you are a musician, a band or musical group you sign up agreeing to share your data via your Resume, (including your posted music) with other Music is Vivid site visitors, Site Members, Agents, Agencies and other Musicians and Bands. If you purchase something from our store, as part of the buying and selling process, we collect the personal information you give us such as your name, address and email address.</span></span></span></span></span></p>
<p><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">With your permission and as part of the sign up process, we may send you emails about our Venues, Contests, Information about Musicians and their genres and store product information and other updates.</span></span></span></p>
<h3 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>PERSONAL INFORMATION</u></span></span></span></h3>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Under no circumstances do we transfer your email address to any other company, nor do we collect any personal data not included in the Musician resume or visitor/fan sign up process. .</span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">There are two ways you can provide us with and consent to our collection of certain personal information:</span></span></span></span></span></p>
<h3 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><u>E-MAIL REQUEST</u></span></span></h3>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Links throughout our site provide you with the opportunity to contact us via e-mail to ask questions, request information and materials, or provide comments and suggestions. You may also be offered the opportunity to have one of our staff contact you personally to provide additional information about our products. To do so, we may request additional personal information from you, such as your name and telephone number, to help us satisfy your request.</span></span></span></span></span></p>
<h3 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><u>SIGNUP OR ENROLLMENT</u></span></span></h3>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">You may choose to sign up or enroll as an Artist for one of our products or services and we will request certain information from you. Depending on the type of product or service that you request, you may be asked to provide different personal information. For certain products and services, we may require your name, address, telephone number, e-mail address, and credit card number. Other products and services may require different or supplemental information from you in order to apply.</span></span></span></span></span></p>
<h2 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><u>YOUR ABILITY TO OPT-OUT OF FURTHER NOTIFICATIONS</u></span></span></span></h2>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">Periodically, we notify our customers of new products, announcements, and updates. If you would like to opt-out of being notified, please contact us at&nbsp;</span></span></span><span style="font-family: Arial, serif;"><span style="font-size: small;">admin@musicisvivid.com</span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><br /></span></span></span></span></span><br /><br /></p>
<h3 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><u>CHANGES TO THIS PRIVACY POLICY</u></span></span></h3>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and clarifications will take effect immediately upon their posting on the website. If we make material changes to this policy, we will notify you here that it has been updated, so that you are aware of what information we collect, how we use it, and under what circumstances, if any, we use and/or disclose it.</span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If our store is acquired or merged with another company, your information may be transferred to the new owners so that we may continue to sell products to you.</span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>COOKIES POLICY</strong></span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">By using the Music is Vivid Site (or app), you are consenting to our use of cookies and other tracking technology in accordance with this notice. If you do not agree to our use of cookies and other tracking technology in this way, you should set your browser settings accordingly or not use the Music is Vivid Site. If you disable cookies that we use, this may impact your user experience while on the Music is Vivid Site.</span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>WHAT ARE COOKIES?</strong></span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">Cookies are small text files that are placed on your computer by websites that you visit. They are widely used in order to make websites work, or work more efficiently, as well as to provide information to the owners of the site.</span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>WHAT TYPE OF COOKIES DOES MUSIC IS VIVID USE?</strong></span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">The following types of cookies are used on Music is Vivid websites. </span></span></span></span></span></span></p>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>Necessary Cookies</strong></span></span></span></span></span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">These are cookies that are strictly necessary for the operation of a website. Without these cookies, this website won&rsquo;t work properly. Accordingly, we are not asking you for your specific consent for those cookies. For all other cookies your informed consent is required.</span></span></span></span></span></span></p>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>Session Cookie</strong></span></span></span></span></span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">Session cookies are temporary cookie files which are erased when you close your browser. When you restart your browser and go back to the site that created that cookie, the website will treat you as a new visitor.</span></span></span></span></span></span></p>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>Functional / Persistent Cookies</strong></span></span></span></span></span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">These are cookies which are set up to improve the functionality of the website. For example, cookies that remember the content you previously viewed on this website or the email address and password you provided when registering during an earlier visit to this website. Cookies may also remember items you have previously placed in your shopping cart while visiting Music is Vivid website. Using Functional cookies, therefore, may allow us to serve you content tailored to your interests and save you the time of having to re-register or re-enter information when you re-visit this website or try to access certain member-only sections. On some websites, cookies enable us to store your favourite recipes, activities, points or high scores. We may also use Cookies to lockout underage users from certain activities.</span></span></span></span></span></span></p>
<ul>
<li>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>Cookies that send information to us</strong></span></span></span></span></span></span></p>
</li>
</ul>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">These are the cookies that we set on Music is Vivid Site and they can only be read by that site. This is known as a </span></span></span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>"First Party"</strong></span></span></span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"> cookie.</span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">We also place cookies on brand ads which are placed on other websites owned by third parties. We obtain information via those cookies when you click on or interact with the advertisement. In this situation the brand is placing a </span></span></span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>&ldquo;Third Party&rdquo;</strong></span></span></span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"> cookie. The brand may use the information obtained by these cookies to serve you with advertising that is relevant and of interest to you based on your past online behaviour.</span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>HOW AND WHY DOES </strong></span></span></span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>MUSIC IS VIVID </strong></span></span></span></span><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>USE THEM?</strong></span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">Music is Vivid uses cookies to gain a better understanding how visitors use this website. Cookies help us tailor Music is Vivid websites to your personal needs, to improve their user-friendliness, gain customer satisfaction feedback on our websites (through designated partners) and to communicate to you elsewhere on the web. To enable this some cookies are applied when you enter our sites.</span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">Music is Vivid keeps all the information collected from cookies in a non&ndash;personally identifiable format. Music is Vivid cookies located on your computer do not retain your name or your IP address.</span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB"><strong>HOW TO CONTROL COOKIES / TURNING OFF COOKIES</strong></span></span></span></span></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;"><span lang="en-GB">If you would like to delete cookies or instruct your web browser to delete or refuse cookies, please visit the help pages of your web browser. Please note, however, that if you delete cookies or refuse to accept them, you might not be able to use all of the features we offer, you may not be able to store your preferences, and some of our pages might not display properly.</span></span></span></span></span></span></p>
<h3 class="western"><br /><br /></h3>
<h3 class="western"><span style="color: #000000;"><span style="font-family: Arial, serif;"><u>QUESTIONS AND CONTACT INFORMATION</u></span></span></h3>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">If you would like to: access, correct, amend or delete any personal information we have about you, register a complaint, or simply want more information contact us by email </span></span></span><a href="mailto:admin@musicisvivid.com"><span style="font-family: Arial, serif;"><span style="font-size: small;">admin@musicisvivid.com</span></span></a></span></span></p>
<p><span style="font-family: Times New Roman, serif;"><span style="font-size: medium;"><span style="color: #656565;"><span style="font-family: Arial, serif;"><span style="font-size: small;">or by mail at; Music is Vivid, 5401 S. Kirkman Rd ste 310 , Orlando, FL 32819-7937</span></span></span></span></span></p>
<p>&nbsp;</p>
<h2 class="western"><br /><br /></h2>
<p><br /><br /></p>
		


</div>
</div>
</template>

<script>
import router from '../router';
import AppHeader from "@/components/AuthHeader.vue";
export default {
  name: 'UserAgreement',
  data() {
   return {
       user: JSON.parse(localStorage.getItem("User")),
   };
  },
  components: {
    AppHeader
},
methods:{

},
created(){

},

mounted(){

},

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.agreement-text {
    margin: 40px;
    box-shadow: 0 1px 6px 0px rgba(0,0,0,0.16);
    padding: 30px;
}
</style>