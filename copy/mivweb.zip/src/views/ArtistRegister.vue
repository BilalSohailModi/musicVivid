<template>
<div class="homegb">
   <AppHeader></AppHeader>
  <div class="artist-sign-up-container">
         <div class="container">
            <div class="row">
               <div class="artist-sign-up-wraper">
				   <form action="artist-sign-up-step-2.html"  @submit.prevent="validateBeforeSubmit">
               <p v-if="errors.length">
                <b>Please correct the following error(s):</b>
                <ul>
                  <li v-for="(error,index ) in errors" :error="error" :key="index">{{ error }}</li>
                </ul>
              </p>
			 
                  <div class="ar-signup-heading-container">
                     <h1>Create Account</h1>
                     <p>Are You an Artist, Want to Share Your Music! </p>
				  </div>
				  
				   <span class="error-messages" v-if="$store.state.registerdata2.error">
                                    {{$store.state.registerdata2.errormessage}}
                                  </span>
                  <div class="filds-group mb-20" :class="{'input': true, 'error': errors.has('Full Name')}">
                     <div class="fild-icon">
                        <img src="/assets/images/user-icon.png">
                     </div>
                     <input id="" type="text" class="filds"  autocomplete="new"  v-model="rgisterdata.fullName" name="Full Name" v-validate="'required'" data-vv-delay="500"
                  :class="{'input': true, '': errors.has('Full Name') }" placeholder="Full name">
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                        	<span class="message"  v-show="errors.has('Full Name')">{{ errors.first('Full Name') }}</span>
                     </div>
                  </div>
                  <div class="filds-group mb-20" :class="{'input': true, 'error': errors.has('Phone No') }" >
                     <div class="fild-icon">
                        <img src="/assets/images/Phone-icon.png">
                     </div>
                     <input id="" onkeydown="javascript: return event.keyCode === 8 || event.keyCode === 46 ? true : !isNaN(Number(event.key))" type="number" class="filds" autocomplete="new"  v-model="rgisterdata.phoneNo" name="Phone No" v-validate="'required|max:10|min:10|regex:^[0-9]'" data-vv-delay="500"
                  :class="{'input': true, '': errors.has('Phone No') }" placeholder="Phone Number">
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                         	<span class="message"  v-show="errors.has('Phone No')">{{ errors.first('Phone No') }}</span>
                     </div>
                  </div>
                  <div class="filds-group mb-20" :class="{'input': true, 'error': errors.has('Email') }" >
                     <div class="fild-icon">
                        <img src="/assets/images/mail-icon.png">
                     </div>
                     <input id="" type="email" class="filds" autocomplete="off" v-model="rgisterdata.email" name="Email" v-validate="'required|email'" data-vv-delay="1000" placeholder="Email">
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                        	<span class="message"  v-show="errors.has('Email')">{{ errors.first('Email') }}</span>
                     </div>
                  </div>
                  <div class="filds-group mb-20" :class="{'input': true, 'error': errors.has('Password') }">
                     <div class="fild-icon">
                        <img src="/assets/images/Password-icon.png">
                     </div>
                     <input id="" type="password" class="filds" autocomplete="off" name="Password" v-model="rgisterdata.password" v-validate="'required|min:8'" data-vv-delay="1000" :class="{'input': true, 'is-danger': errors.has('Password') }" placeholder="Password">
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                        	<span class="message"  v-show="errors.has('Password')">{{ errors.first('Password') }}</span>
                     </div>
				  </div>
				  <div class="sign_unsign-div">
				   <p>Are you signed with a major label </p>

							  <label class="radio-div">Unsigned
									<input type="radio" v-validate="'required'"  v-model="rgisterdata.signedType"  name="Sign Unsign" value="2">
									<span class="img-checkmark unsign-check"></span>
								  </label>
                  						<label class="radio-div">Signed
								<input type="radio" v-validate="'required'"   v-model="rgisterdata.signedType" name="Sign Unsign" value="1">
								<span class="img-checkmark sign-check"></span>
							  </label>
								   <span v-show="errors.has('Sign Unsign')" class="text-danger">{{ errors.first('Sign Unsign') }}</span>
				  </div>
				  
				  <!-- social channel -->
				<div class="social-channel-div">
					  <label>Prefered Channel</label>
               
					 
            <div class="sign_unsign-div">
                <label class="radio-channel">
                    <input type="radio" name="Prefer Channel"  v-validate="'required'"  v-model="rgisterdata.prefferedChannel"  value="1">
                    <span class="channel-checkmark"><i class="fa fa-youtube-play" aria-hidden="true"></i>Youtube</span>
                    </label>
                    <label class="radio-channel">
                      <input type="radio"  v-validate="'required'" v-model="rgisterdata.prefferedChannel" name="Prefer Channel" value="2">
                      <span class="channel-checkmark"><i class="fa fa-vimeo" aria-hidden="true"></i>Vimeo</span>
                      </label>
                       <span v-show="errors.has('Prefer Channel')" class="text-danger">{{ errors.first('Prefer Channel') }}</span>
              </div>
				  </div>
                  <!-- channel -->
                  <div class="filds-group mb-20" :class="{'input': true, 'error': errors.has('Channel Name') }">
                     <div class="fild-icon">
                        <img src="/assets/images/channel-icon.png">
                     </div>
                     <input type="text" autocomplete="off" class="filds"  v-model="rgisterdata.channelName" name="Channel Name" v-validate="'required'" data-vv-delay="500"
                  :class="{'input': true, '': errors.has('Channel Name') }" placeholder="Channel Name" id="">
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                        <span class="message"  v-show="errors.has('Channel Name')">{{ errors.first('Channel Name') }}</span>
                     </div>
                  </div>
                  <div class="filds-group mb-20" :class="{'input': true, 'error': !isCity }">
                     <div class="fild-icon">
                        <img src="/assets/images/home-town-icon.png">
                     </div>
                     <vue-google-autocomplete v-model="rgisterdata.address" v-on:inputChange="checkingCity" name="address"   id="map1" v-validate="'required'"   ref="address" types="(cities)" classname="filds" :country="geocode" placeholder="Home Town" v-on:placechanged="getAddressData">
                    </vue-google-autocomplete>
                     <!-- <input type="text" class="filds" placeholder="Home Town" id=""> -->
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                        <span class="message"  v-show="!isCity">City field is required.</span>
                     </div>
				         </div>
				  
				  <button class="btn-signin success_msg_btn" type="submit">Continue</button>

				</form>

				<ul class="step-count-ul">
					<li class="active"></li>
					<li></li>
					<li></li>
					<li></li>
				</ul>
               </div>
            </div>
         </div>
      </div>
      <div> <AppFooter></AppFooter></div>
    

       <!-- upload my music modal  -->
    <div class="modal fade" id="upload-model-view" data-backdrop="static" data-keyboard="false">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <div><b>I want MIV to upload my music</b></div>
            <button type="button" class="close" @click="closeModel()" aria-hidden="true">×</button>
          </div>
          <!-- Modal body -->
          <div class="modal-body">
            <div class="modal-video-container">
              <div class="text-center">
                <div class="filds-group mb-20">
                     <div class="fild-icon">
                        <img src="/assets/images/user-icon.png">
                     </div>
                     <input id="" v-model="uploadForm.fullName" type="text" class="filds"  autocomplete="new"  name="Full Name" placeholder="Full name">
                     <div class="fild-icon-right">
                        <i class="icon-warning"></i>
                        	<span class="message"></span>
                     </div>
                  </div>

                  <div class="filds-group mb-20" v-bind:class="{ error: emailCheck }">
                     <div class="fild-icon">
                        <img src="/assets/images/mail-icon.png">
                     </div>
                     <input id="" v-model="uploadForm.email" type="email" class="filds" autocomplete="off"  name="Email" placeholder="Email" v-on:keyup="ValidateEmail()">
                  </div>

                   <div class="filds-group mb-20" v-bind:class="{ error: phoneCheck }">
                     <div class="fild-icon">
                        <img src="/assets/images/Phone-icon.png">
                     </div>
                     <input id="" v-on:keyup="ValidatePhone()" v-model="uploadForm.phoneNumber" onkeydown="javascript: return event.keyCode === 8 || event.keyCode === 46 ? true : !isNaN(Number(event.key))" type="number" class="filds" autocomplete="new" name="Phone No" placeholder="Phone Number">
                  </div>

                  <div class="filds-group mb-20" v-bind:class="{ error: musicUrlCheck }">
                     <div class="fild-icon">
                        <img src="/assets/images/music-icon.png">
                     </div>
                     <input id="" v-on:keyup="ValidateUrl()" v-model="uploadForm.musicUrl" type="text" class="filds" autocomplete="off"  name="music" placeholder="Music URL">
                  </div>

              <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="agreementChecked" @change="isChecked($event)">
                  <label class="custom-control-label" for="agreementChecked">
                <span class="question-field">
                  Do You Agree To The
                  <span>
                    <a href="/user-agreement" target="_blank">User Agreement</a>
                  </span>
                  For Music is Vivid (MiV) For Artists?
                </span>
              </label>
              </div>
              </div>
             
            </div>
            <div class="modal-div-btn clearfix pt-3 mb-2">
              <button class="btn-signin success_msg_btn" :disabled="isDisable()" @click="submitData">Submit</button>
             
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>
import AppHeader from "@/components/UnauthHeader.vue";
import AppFooter from "@/components/ComonFotter.vue";
import router from "../router";
import VueGoogleAutocomplete from "vue-google-autocomplete";
import {
  API
} from "@/api/api";
export default {
  name: "ArtistRegister",
  props: {
    msg: String
  },
  components: {
    AppHeader,
    AppFooter,
    VueGoogleAutocomplete
  },
  data() {
    return {
      user: {},
      geocode: [],
      isCity: true,
      emailCheck : false,
      phoneCheck: false,
      musicUrlCheck: false,
      checkedVal : false,
      uploadForm: {},
    };
  },
 
  computed: {
    rgisterdata() {
      return this.$store.state.registerdata2;
    }
  },
  methods: {
    checkingCity: function(e) {
      if (e.newVal == "") {
        this.isCity = false;
      } else {
        this.isCity = true;
      }
      this.$store.state.registerdata2.address = e.newVal;
    },
    validateBeforeSubmit() {
      console.log(!this.$store.state.registerdata2.address);
      if(!this.$store.state.registerdata2.address) {
         this.isCity = false;
      } else {
        this.isCity = true;
      }
      this.$validator.validateAll().then(result => {
        if (result) {
            const {email} =this.$store.state.registerdata2;
           API.post("register",  {email:email})
      .then(response => {
       
        if (response.data) {
          console.log(response.data);
          state.registerdata2. error= false;
          state.registerdata2. errormessage = "";
         
       
             
        }
      })
      .catch(error => {
        let data = error.response.data.errors;
      console.log(data);
        if(data.length ==1){
               this.$store. state.registerdata2. error= true;
      this.$store. state.registerdata2. errormessage = data[0].msg;
        }
     else{
sessionStorage.setItem('onwatdata',JSON.stringify(this.$store.state.registerdata2));
          router.push({
            name: "ArtistRegister2"
          });
     }
    // this.$store. state.registerdata2. error= true;
    //   this.$store. state.registerdata2. errormessage = data[0].msg;
       // console.log( state.registerdata);
      });
          
        }
      });
    },
    getAddressData: function(addressData, placeResultData, id) {
      console.log("adress data ==>",placeResultData);
      // console.log(placeResultData);
      
      if(placeResultData && placeResultData.address_components[3]) {
          this.geocode.push(placeResultData.address_components[3].short_name);
      }
      this.$store.state.registerdata2.address =
        placeResultData.formatted_address;
      this.$store.state.registerdata2.latitude = addressData.latitude;
      this.$store.state.registerdata2.longitude = addressData.longitude;
    if(placeResultData && placeResultData.address_components) {
      this.$store.state.registerdata2.country = placeResultData.address_components[2].long_name;
      this.$store.state.registerdata2.city = placeResultData.address_components[0].long_name;
      this.$store.state.registerdata2.state = placeResultData.address_components[1].long_name;
    }


      console.log(this.$store.state.registerdata2);
    },

    closeModel() {
      $("#upload-model-view").modal('hide');
    },
    ValidateEmail() {
      if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.uploadForm.email)) {
      this.emailCheck = false;
    } else {
      this.emailCheck = true;
    }
  },
  ValidatePhone() {
      if (/^\d{10}$/.test(this.uploadForm.phoneNumber)) {
      this.phoneCheck = false;
    } else {
      this.phoneCheck = true;
    }
  },
  ValidateUrl() {
   if(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g.test(this.uploadForm.musicUrl)){
      this.musicUrlCheck = false;
   } else {
      this.musicUrlCheck = true;
   } 
  },
  isChecked(e) {
    if(e.target.checked) {
      this.checkedVal = true;
    } else {
      this.checkedVal = false;
    }
  },
  isDisable() {
    if((!this.uploadForm.email) || (this.uploadForm.email && this.emailCheck)){
      return true 
    } else if((!this.uploadForm.phoneNumber) || (this.uploadForm.phoneNumber && this.phoneCheck)) {
      return true
    } else if((!this.uploadForm.musicUrl) || (this.uploadForm.musicUrl && this.musicUrlCheck)) {
       return true
    }else if(!this.uploadForm.fullName) {
       return true
    } else if(!this.checkedVal) {
      return true
    } else {
      return false
    }
  },
  submitData() {
      var head = {
        headers: { "x-access-token": JSON.parse(localStorage.getItem("Token")) }
      };
      let params = {}
      params.fullname = this.uploadForm.fullName,
      params.email = this.uploadForm.email,
      params.phone = this.uploadForm.phoneNumber,
      params.url = this.uploadForm.musicUrl,
      API.post('new-artist-popup-mail', params, head)
        .then(response => {
          if (response.data) {
            this.uploadForm = {};
            swal(
              "Success",
              "Mail send successfully !",
              "success"
            );
          }
        })
        .catch(error => {});
   }
  },
  mounted() {
    var inputElements = document.getElementsByTagName("input");

    for (let i = 0; inputElements[i]; i++) {
      if (
        inputElements[i].className &&
        inputElements[i].className.indexOf("disableAutoComplete") != -1
      ) {
        inputElements[i].setAttribute("autocomplete", "off");
      }
    }
    this.$refs.address.geolocate();

        setTimeout(() => {
      $("#upload-model-view").modal("show");
      $("#upload-model-view").modal({
       backdrop: "static",
       keyboard: false
      });
    }, 2000);
  },
   created() {
  }
};
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
</style>
